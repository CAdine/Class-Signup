<?php
	include('connect_db.php'); 
	include('sessions.php');
	echo 'Welcome! ' .$_SESSION['username'];
?>
<!DOCTYPE html>

<head>
    <title>Student - Main Menu</title>
        <meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="myCSS.css">
</head>
<body>
<div id="wrapper">
<header> 
<a href ="index.php"><img src = "booklogo.jpg" 
		alt = InfoSchool></a>
		<a href ="index.php">
		<a href ="index.php"> School - Student Menu</a>

</header>	
	<nav>
		<ul>
			<b>
            <li><a href="index.php">Home</a>&nbsp;&nbsp;<a href="logout.php">Logout</a></li>
			</b>
		</ul>
	</nav> 
	<div id="rightcol"> 
	<main>
		
	<center>
	<h3>Search courses</h3>
	<h3>To search courses enter the course ID </h3>
	<h3>EX: INFO, 101, JAVA</h3>
        <form action = "search_course.php" method ="POST">
            <table> 
            <tr><td> Course ID</td><td><input type="search" name="search" placeholder="Seach for courses">
			<input type="submit" id="submit" name="button" value="Search"></td></tr>
				
               		
    				
            </table>

		</form>
	 <?php
					
					
					if(isset($_POST['button'])){
						$search=$_POST['search']; 
						
						$sql = "SELECT *  FROM courses
						WHERE courseID LIKE '%$search%' OR courseName LIKE '%$search%'" ;
						$results = $connect->query($sql);
						if($results->num_rows>0){
						
							//display results
							while($row=$results->fetch_assoc()){
							
								echo "<br>Results: " .$row['courseID']. 
								" - " .$row['courseName'],
								" - " .$row['teacherID'],
								" - " .$row['startTime'],
								" - " .$row['endTime'],
								" - " .$row['CRN'];  
								
			 				
			 				}
							
						}
		
					
					}					
        		?>
               		
	</center>
	<br>
	</main>
   
</div>


<footer><i>Copyright @ 2017 School Registration </footer>
</div>       
</body>

</html>