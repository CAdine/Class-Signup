<?php
	include('connect_db.php'); 
	include('sessions.php');
	echo 'Welcome! ' .$_SESSION['username'];
?>
<!DOCTYPE html>

<head>
    <title>Student - Main Menu</title>
        <meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="myCSS.css">
		
</head>
<body>
<div id="wrapper">
<header> 
<a href ="index.php"><img src = "booklogo.jpg" 
		alt = InfoSchool></a>
		<a href ="index.php">
		<a href ="index.php"> School - Student Menu</a>

</header>	
	<nav>
		<ul>
			<b>
            <li><a href="index.php">Home</a>&nbsp;&nbsp;<a href="logout.php">Logout</a></li>
			</b>
		</ul>
	</nav> 
	<div id="rightcol"> 
	<main>
		
	<center>
	<h1> Student Menu </h1>
    <h3>View Courses</h3>
        <form action="course_reg.php" method ="POST">
             <table> 
				<tr>
               		<th>Course ID</th>
               		<th>Course Name</th>
					<th>teacherID</th>
					<th>Start Time</th>
					<th>End Time</th>
					<th>Semster</th>
					<th>CRN</th>
				</tr>	
		</form>
	<?php
		//only displays course if user is logged in
            if(isset($_SESSION['username'])){
		
				$sql = "SELECT * FROM courses"; 
					$result = $connect->query($sql);
					if ($result->num_rows > 0) {
					// output data of each row
					//add output into table row
					while($row = $result->fetch_assoc()) {
						
					echo "<tr><td>" . $row["courseID"]. "</td><td>". 
					$row["courseName"]. "</td><td>".
					$row["teacherID"]. "</td><td>".		
					$row["startTime"]. "</td><td>".
					$row["endTime"]. "</td><td>".
					$row["semester"]. "</td><td>".
					$row["CRN"]. "</td></tr>";					
					}	
					echo"</table>";

				}
			}
	?>
	<h3>Add courses for next semester </h3>
			<h3>Add Student ID and seation ID to add to timetable</h3> 
			<form action="registration.php" method ="POST">
               		<table> 
               			<tr><td>Enter StudentID: </td><td><input type="text" id="stuID" name="stuID"required></td>
						<tr><td>Enter CRN: </td><td><input type="text" id="secID" name="secID"required></td>
						
						
            <?php
				if(isset($_POST['stuID'])){ 
					if(isset($_POST['secID'])){
						//add code so users cannot register unless logged in
						//Before using post
						//Add to other errors 
						
						$studID="";
						$secID="";
						$stuID = $_POST['stuID']; 
						$secID = $_POST['secID'];
							//search through the registration database to see if user already is registered
							$sDB = "SELECT courseID FROM registration 
							WHERE studentID ='".$_SESSION['username']."' ";
							$dbresults=$connect->query($sDB);
							

							if($sDB!=$secID){
								//$sql ="INSERT INTO registration (studentID) VALUES('$studID')"; 
								
								$sql = "INSERT INTO registration (studentID, courseID, courseName,
								startTime, endTime, semester, CRN) SELECT '$_POST[stuID]', courseID,
								courseName, startTime, endTime, semester, CRN FROM courses WHERE CRN=
								'".$_POST['secID']."'";  
								
								$result=$connect->query($sql);
								
								if($result==TRUE){
									
									echo"<center>Course added!</center>";
								}else{
									echo"ERROR! Already Registered to Course!";
								}
								
								//If students try to register for more than 3 courses
								/*$sql1 = "SELECT COUNT(studentID) FROM registration WHERE studentID='".$_SESSION['username']."'"; 
								$count =$connect->query($sql1);
								while($row=$count->fetch_assoc()){
						
									$count=$row['COUNT(studentID)'];
									
									if($count>3){
									echo "Cannot sign for more than 3 courses!"; 
									}
								}*/
								
					
								
								
								/*if($count>3){
									echo "Cannot sign for more than 3 courses!"; 
								}*/
								
							}else{
								echo"ERROR! Already in the course!"; 
							}
							
							
            
					}
				}
			
			?>
					
					
					</table>
					<a href="registration.php">Add Courses</a>
					<a href="view_student_timetable.php">Timetable for Courses</a>
					<center><br><input type="submit" id="submit" name="submit" value="Register"><br><br></center>
					
					
               </form>
	</table><br>
        <a href="registration.php">Register for Courses</a></li>
         </form>
               		
	</center>
	</main>
   
	</div>


<footer><i>Copyright @ 2017 School Registration </footer>
</div>       
</body>

</html>