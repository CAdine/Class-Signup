<?php
	include('connect_db.php'); 
	include('sessions.php');
	echo 'Welcome! ' .$_SESSION['username'];
?>
<!DOCTYPE html>

<head>
    <title>Student - Main Menu</title>
        <meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="myCSS.css">
</head>
<body>
<div id="wrapper">
<header> 
<a href ="index.php"><img src = "booklogo.jpg" 
		alt = InfoSchool></a>
		<a href ="index.php">
		<a href ="index.php"> School - Student Menu</a>

</header>

	<nav>
		<ul>
			<b>
            <li><a href="index.php">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;
			<a href="logout.php">Logout</a></li>
			</b>
		</ul>

	</nav>
	
	<div id="rightcol"> 
	<main>
	
		
	<center><h1>&nbsp;&nbsp;&nbsp;Student Menu - Payment Due</h1>
	<h3>View total amount for Courses</h3>
        <form action="course_reg.php" method ="POST">
            <table> 
               	<tr>
               				
               	<th>Amount of courses</th>
				<th>Total Amount due</th>
				</tr>	
		<?php
					//only displays course if user is logged in
            		if(isset($_SESSION['username'])){
					
					
					$sql = "SELECT COUNT(studentID) FROM registration WHERE 
					studentID='".$_SESSION['username']."'"; 
					$result = $connect->query($sql);
					
					while($row=$result->fetch_assoc()){
						
						$count=$row['COUNT(studentID)'];
						echo "<tr><td><center>".$count."</td></center>";
					}
					$coursePrice =250; 
					$taxrate = 0.12;
					$totalamount= $coursePrice * $count;
					$totalamount= $totalamount *(1 +$taxrate); 

						echo "<td><center>Total amount including tax: "
						.number_format($totalamount,2)."</td></tr></center>";
						
					
			
			}			
				
		?>		
				
      
      </table> <br>
	</div>  
	</center>
	</main>

	<footer><i>Copyright @ 2017 School Registration </footer>
	



</div>       
</body>

</html>