<?php
	include('connect_db.php'); 
	include('sessions.php');
	echo 'Welcome! ' .$_SESSION['username'];
?>
<!DOCTYPE html>

<head>
    <title>Student - Main Menu</title>
        <meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="myCSS.css">
</head>
<body>
<div id="wrapper">
<header> 
<a href ="index.php"><img src = "booklogo.jpg" 
		alt = InfoSchool></a>
		<a href ="index.php">
		<a href ="index.php"> School - Student Menu</a>

</header>

	<nav>
		<ul>
			<b>
            <li><a href="index.php">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;
			<a href="logout.php">Logout</a></li>
			</b>
		</ul>

	</nav>
	
	<div id="rightcol"> 
	<main>
		
	<center><h1>&nbsp;&nbsp;&nbsp;Student Menu - Contacts</h1>
     <?php
		
		if(isset($_SESSION['username'])){
		
			$sql = "SELECT teacherID, teacherName, teacherAddress, teacherPhone,
				teacherEmail FROM teacher";
				$result = $connect->query($sql); 
				
				if($result->num_rows>0){
					//display outputs
					while($row=$result->fetch_assoc()){
					
					echo "<br><br>Teacher ID: " . $row["teacherID"].
					"<br>Teacher Name: " .$row["teacherName"].
					"<br>Address: " .$row["teacherAddress"].
					"<br>Phone: " .$row["teacherPhone"].
					"<br>Email: " .$row["teacherEmail"];
					}
				}
			}
		
		
		?>
	
    </div> 

	</center>
	</main>
   
	


<footer><i>Copyright @ 2017 School Registration </footer>
</div>       
</body>

</html>