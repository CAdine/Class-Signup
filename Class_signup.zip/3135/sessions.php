<?php
	session_start(); 
	if(isset($_POST['btnLogin'])){
		require 'connect_db.php'; 
		$username =  $_POST['username'];
		$password = $_POST['password'];
		$studentName=""; 
		$dateOfBirth="";
		$studentAddress=""; 
		$studentPhone=""; 
		$studentEmail="";
		$semester="";
		
		$result = mysqli_query($connect,'SELECT studentID, password, studentName, 
		dateOfBirth, studentAddress, studentPhone, studentEmail, sesmester FROM student 
		WHERE studentID="'.$username.'" AND password ="'.$password.'" AND 
		studentName="'.$studentName.'" AND dateOfBirth="'.$dateOfBirth.'" AND
		studentAddress="'.$studentAddress.'" AND studentPhone="'.$studentPhone.'" AND
		studentEmail="'.$studentEmail.'"AND semester="'.$semester.'"');
		
				
		if(mysqli_num_rows($result)==1)
		{
			// if they are in the database register the user id
			$_SESSION['username'] = $username;
			$_SESSION['studentName'] =$studentName; 
			$_SESSION['dateOfBirth'] =$dateOfBirth;
			$_SESSION['studentPhone'] =$studentPhone;  
			$_SESSION['studentEmail'] =$studentEmail;
			$_SESSION['semester'] =$semester;  
			
			header("Location: index.php");
		}
		else{
			echo"Error! Incorrect ID and/or password!"; 
			header("Location: login_check.php");
		}
}
?>